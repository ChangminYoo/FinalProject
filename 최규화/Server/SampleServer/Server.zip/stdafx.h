#pragma once
#pragma once
#include <windows.h>
#include <math.h>
#include <time.h>
#include <string>
#include <stdlib.h>
#include <conio.h>
#include <mmsystem.h>
#include <iostream>
#include <map>
#include <vector>
#include <random>

using namespace std;

struct Pos
{
	int x;
	int y;
};
//��ȣ ��� func\n{} ������ �� 

//ĳ���� ���� ����ü

enum PACK_TYPE
{
	SELECT_ROOM,
	WAIT_ROOM,
	STAGE_TIME,
	CHARACTER_INFO,
	OBSTACLE_CAR,
	OBSTACLE_LASER,
	ITEM_CLICK,
	GAME_OVER
};
#pragma pack(1)
struct CharacterInfo
{

	PACK_TYPE packType = PACK_TYPE::CHARACTER_INFO;
	union
	{
		Pos char_pos;
		int score;
		u_short id;
		int life;
	}S_un;
};
#pragma pack()

//�ڵ��� ��ֹ� ���� ����ü
#pragma pack(1)
struct CarObjectInfo
{

	PACK_TYPE packType = PACK_TYPE::OBSTACLE_CAR;
	int posY[8];

};
#pragma pack()

#pragma pack(1)
struct ItemObjectInfo
{

	PACK_TYPE packType = PACK_TYPE::ITEM_CLICK;
	union
	{
		Pos item_pos;
		bool is_alive;
		u_short id;

	}C_un;
};
#pragma pack()

#pragma pack(1)
struct ObstacleObjectInfo
{

	PACK_TYPE packType = PACK_TYPE::OBSTACLE_LASER;
	union
	{
		bool is_alive;
		bool is_break;
		u_short id;
		float clearTime;

	}C_un;
};
#pragma pack()

//�ð� ���� ����ü
#pragma pack(1)
struct TimeInfo
{
	PACK_TYPE packType = PACK_TYPE::STAGE_TIME;
	double game_Play_Time;
};
#pragma pack()


//��� �� ���� ���� ����ü
#pragma pack(1)
struct Wait_Room
{
	union {
		PACK_TYPE packType = PACK_TYPE::WAIT_ROOM;
		bool game_ready;
		struct {
			Pos char_pos;
			int resource_type;
			u_short id;
		}S_Client_Info;
		bool game_start;
	}S_wr;

};
#pragma pack()

//ĳ���� ���� ���� ����ü
#pragma pack(1)
struct Character_Select
{
	// PacketInfo�� packetType = 7
	PACK_TYPE packType = PACK_TYPE::SELECT_ROOM;
	int character_type;
	bool go_to_wr;
	int character_left;
	u_short id;
};
#pragma pack()


//���� ���� �Ǵ� ����ü
#pragma pack(1)
struct Game_Info
{
	PACK_TYPE packType = PACK_TYPE::GAME_OVER;
	int score;
	u_short id;
	bool will_replay;
};
#pragma pack()

