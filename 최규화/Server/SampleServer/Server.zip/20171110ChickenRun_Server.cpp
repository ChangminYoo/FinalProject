#pragma comment(lib,"ws2_32")
#pragma warning(disable:4996)
#include <WinSock2.h>
#include <stdlib.h>
#include <stdio.h>
#include <io.h>
#include <fcntl.h>
#include <vector>
#include "stdafx.h"
#define SERVERIP "127.0.0.1"
#define SERVERPORT 9000
#define BUFSIZE 512

//���� �Լ� ���� ��� �� ����

void err_quit(char* msg) 
{
	LPVOID lpMsgBuf;
	FormatMessage(
		FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
		NULL, WSAGetLastError(),
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR)&lpMsgBuf, 0, NULL);
	MessageBox(NULL, (LPCTSTR)lpMsgBuf, msg, MB_ICONERROR);
	LocalFree(lpMsgBuf);
	exit(1);
}

void err_display(char *msg)
{
	LPVOID lpMsgBuf;
	FormatMessage(
		FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
		NULL, WSAGetLastError(),
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR)&lpMsgBuf, 0, NULL);
	printf("[%s] %s", msg, (char *)lpMsgBuf);
	LocalFree(lpMsgBuf);
}
//����� ���� ������ ���� �Լ�
int recvn(SOCKET s, char* buf, int len, int flags) {
	int received;
	char* ptr = buf;
	int left = len;
	while (left > 0) {
		received = recv(s, ptr, left, flags);
		if (received == SOCKET_ERROR)
			return SOCKET_ERROR;
		else if (received == 0)
			break;
		left -= received;
		ptr += received;
	}
	return (len - left);


}
DWORD WINAPI Player1Thread(LPVOID arg)
{
	SOCKET client_sock = (SOCKET)arg;
	int retval;
	SOCKADDR_IN clientaddr;
	int addrlen;
	CharacterInfo chrinfo;
	CarObjectInfo carinfo;
	ItemObjectInfo iteminfo;
	ObstacleObjectInfo objinfo;
	TimeInfo timeinfo;
	Wait_Room wrinfo;
	Character_Select csinfo;
	Game_Info gameinfo;
	ZeroMemory(&csinfo, sizeof(csinfo));

	//Ŭ���̾�Ʈ ���� ���
	addrlen = sizeof(clientaddr);
	
	getpeername(client_sock, (SOCKADDR*)&clientaddr, &addrlen);
	csinfo.packType = PACK_TYPE::SELECT_ROOM;
	csinfo.character_type = 0;
	csinfo.go_to_wr = false;
	csinfo.character_left = 0;
	csinfo.id=0;
	
	retval = send(client_sock, (char*)&csinfo, sizeof(csinfo), 0);
	if (retval == SOCKET_ERROR)
	{
		err_display("send()");
		return 0;
	}

	retval = recvn(client_sock, (char*)&csinfo, sizeof(csinfo), 0);
	if (retval == SOCKET_ERROR)
	{
		err_display("recv()");
		return 0;
	}

	retval = send(client_sock, (char*)&csinfo, sizeof(csinfo), 0);
	csinfo.character_type;
	while (1) {
		//������ �ޱ�
		
		
		if (retval == SOCKET_ERROR) 
		{
			err_display("recv()");
			break;
		}
		else if (retval == 0) 
		{
			break;
		}
		
		
	}
	//closesocket()
	closesocket(client_sock);
	printf("[TCP ����] Ŭ���̾�Ʈ ����: IP �ּ� =%s,��Ʈ ��ȣ=%d\n", inet_ntoa(clientaddr.sin_addr), ntohs(clientaddr.sin_port));

	return 0;
}


int main(int argc, char* argv[]) 
{
	int retval;
	//���� �ʱ�ȭ
	WSADATA wsa;
	if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
		return 1;

	//socket()
	SOCKET sock = socket(AF_INET, SOCK_STREAM, 0);
	if (sock == INVALID_SOCKET)
		err_quit("socket()");

	printf("CharcterInfo size: %d\n", sizeof(CharacterInfo));
	printf("CarObjectInfo size: %d\n", sizeof(CarObjectInfo));
	printf("ItemObjectInfo size: %d\n", sizeof(ItemObjectInfo));
	printf("ObstacleObjectInfo size: %d\n", sizeof(ObstacleObjectInfo));
	printf("Game_Info size: %d\n", sizeof(Game_Info));
	printf("Character_Select size: %d\n", sizeof(Character_Select));
	printf("Wait_Room size: %d\n", sizeof(Wait_Room));
	printf("TimeInfo size: %d\n", sizeof(TimeInfo));

	//bind()
	SOCKADDR_IN serveraddr;
	ZeroMemory(&serveraddr, sizeof(serveraddr));
	serveraddr.sin_family = AF_INET;
	serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);
	serveraddr.sin_port = htons(SERVERPORT);
	retval = bind(sock, (SOCKADDR *)&serveraddr, sizeof(serveraddr));
	if (retval == SOCKET_ERROR) 
		err_quit("bind()");
	retval = listen(sock, SOMAXCONN);
	if (retval == SOCKET_ERROR)
		err_quit("listen()");

	
	SOCKET client_sock;
	SOCKADDR_IN clientaddr;
	ZeroMemory(&client_sock, sizeof(client_sock));
	ZeroMemory(&clientaddr, sizeof(clientaddr));
	int addrlen;
	HANDLE hThread;
	while (1) 
	{
		// accept()
		addrlen = sizeof(clientaddr);
		client_sock = accept(sock, (SOCKADDR *)&clientaddr, &addrlen);
		if (client_sock == INVALID_SOCKET) 
		{
			err_display("accept()");
			break;
		}
		// ������ Ŭ���̾�Ʈ ���� ���

		printf("\n[TCP ����] Ŭ���̾�Ʈ ����: IP �ּ�=%s, ��Ʈ ��ȣ=%d\n", inet_ntoa(clientaddr.sin_addr), ntohs(clientaddr.sin_port));
		hThread = CreateThread(NULL, 0, Player1Thread, (LPVOID)client_sock, 0, NULL);
		if (hThread == NULL) {
			closesocket(client_sock);
		}
		else {
			CloseHandle(hThread);
		}
		closesocket(client_sock);
	}
	closesocket(sock);
	WSACleanup();
	return 0;
}


