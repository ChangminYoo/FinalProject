#pragma comment(lib,"ws2_32")
#pragma warning(disable:4996)
#include <WinSock2.h>
#include <stdlib.h>
#include <stdio.h>
#include <io.h>
#include <fcntl.h>
#include <vector>
#include "stdafx.h"
#define SERVERIP "127.0.0.1"
#define SERVERPORT 9000
#define BUFSIZE 512

//���� �Լ� ���� ��� �� ����

HANDLE hCharacterSelectEvent;
HANDLE hSendEvent;
WaitRoomCharInfo g_waitRoomCharInfo = { { -1 },{ -1,-1 },{ -1 },{ -1,-1 },{ -1 },{ 115/*IDB_BITMAP12*/ },{ -1 } };
WaitRoomWhoIsSelected g_waitRoomSel = { { -1,-1 },{ false,false } ,{ 124,124 } ,{ 122,122 } };;
int ready_people = 0;
//�������� ����ϰ� �ִ� ��Ŷ���� ����
PacketClass packet_Folder;
CharacterInfo g_cinfo[2];
int carposx[8] = { 140,200,260,320,410,470,530,600 };
int sendtype = 0;
int sendid=0;
int tempcount=0;
int usercount = 0;
CarObjectInfo carinfo;
void MoveCar(CarObjectInfo);
bool IsCollide(CharacterInfo,CarObjectInfo);
void err_quit(char* msg) 
{
	LPVOID lpMsgBuf;
	FormatMessage(
		FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
		NULL, WSAGetLastError(),
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR)&lpMsgBuf, 0, NULL);
	MessageBox(NULL, (LPCTSTR)lpMsgBuf, msg, MB_ICONERROR);
	LocalFree(lpMsgBuf);
	exit(1);
}

void err_display(char *msg)
{
	LPVOID lpMsgBuf;
	FormatMessage(
		FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
		NULL, WSAGetLastError(),
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR)&lpMsgBuf, 0, NULL);
	printf("[%s] %s", msg, (char *)lpMsgBuf);
	LocalFree(lpMsgBuf);
}
//����� ���� ������ ���� �Լ�
int recvn(SOCKET s, char* buf, int len, int flags) {
	int received;
	char* ptr = buf;
	int left = len;
	while (left > 0) {
		received = recv(s, ptr, left, flags);
		if (received == SOCKET_ERROR)
			return SOCKET_ERROR;
		else if (received == 0)
			break;
		left -= received;
		ptr += received;
	}
	return (len - left);


}


DWORD WINAPI Player1Thread(LPVOID arg)
{
	SOCKET client_sock = (SOCKET)arg;
	int retval;
	int g_nextSceneCnt = 0;
	SOCKADDR_IN clientaddr;
	int addrlen;
	//PacketClass packet_Party;
	Game_Info gameinfo;
	int count = 0;
	Character_Select csinfo2;
	Character_Select csinfo3;
	CharacterInfo cinfo;
	WaitRoomWhoIsSelected m_waitRoomSel;
	//CharacterInfo cinfo2;
	bool m_StopOneID = false;
	bool m_StopTwoID = false;

	bool isW = true;
	CarObjectInfo carinfo2;
	Wait_Room wrinfo;
	Wait_Room wrinfo2;
	int scenetype = 0;
	//ZeroMemory(&csinfo, sizeof(csinfo));
	//retval = WaitForSingleObject(hSendEvent, INFINITE);
	//Ŭ���̾�Ʈ ���� ���
	addrlen = sizeof(clientaddr);
	
	getpeername(client_sock, (SOCKADDR*)&clientaddr, &addrlen);
	

	csinfo2.go_to_wr = false;
	csinfo2.id = sendid + 1;
	
	int tempid;
	tempid= 0;
	sendid++;
	cinfo.packType = PACK_TYPE::CHARACTER_INFO;
	cinfo.life = 20;
	cinfo.score = 0;
	
	packet_Folder.InitializePacket();
	if (tempid == 1) {
	//	cinfo2.char_pos.x = htonl(60);
	//	cinfo2.char_pos.y = htonl(400);
		cinfo.char_pos.x = 640;
		cinfo.char_pos.y = 400;
	}
	else {
	//	cinfo2.char_pos.x = 640;
	//	cinfo2.char_pos.y = 400;
		cinfo.char_pos.x = 60;
		cinfo.char_pos.y = 400;
	}
	
	ZeroMemory(&carinfo, sizeof(carinfo));
	for (int i = 0; i < 8; ++i)
		carinfo.posY[i] = 100;

	int count5 = 0;
	
	int selected = -1;
	bool isR=true;
	while (1)
	{
		count = (count + 1) % 200;
		if (count == 15) {
			
			retval = send(client_sock, (char*)&scenetype, sizeof(int), 0);
			if (retval == SOCKET_ERROR)
			{
				err_display("send()");
				break;
			}

			printf("%d����Ʈ ����, ���� ���� %d��°��\n", retval, scenetype + 1);
			if (scenetype == 0)
			{
				if (scenetype != 1 && scenetype != 2) {
					retval = send(client_sock, (char*)&tempid, sizeof(int), 0);
					if (retval == SOCKET_ERROR)
					{
						err_display("send()");
						break;
					}

					retval = send(client_sock, (char*)&selected, sizeof(int), 0);
					if (retval == SOCKET_ERROR)
					{
						err_display("send()");
						break;
					}
					printf("%d����Ʈ ����, %d�� ������ϴ�. \n", retval, selected);
					retval = recv(client_sock, (char*)&isR, sizeof(bool), 0);
					if (retval == SOCKET_ERROR)
					{
						err_display("recv()");
						break;
					}
					printf("%d����Ʈ ����, �����? %d \n", retval, isR);

				}
				if (!isR) {

					retval = recv(client_sock, (char*)&csinfo3, sizeof(csinfo3), 0);
					if (retval == SOCKET_ERROR)
					{
						err_display("recv()");
						break;
					}

					printf("%d��° ���ſϷ� : What did you choose : %d, %d����Ʈ�� �����߽��ϴ�.\n", count5, csinfo3.id, retval);
					//retval = send(client_sock, (char*)&csinfo2, sizeof(csinfo3), 0);
					retval = send(client_sock, (char*)&scenetype, sizeof(int), 0);
					if (retval == SOCKET_ERROR)
					{
						err_display("send()");
						break;


						//				}
						retval = recv(client_sock, (char*)&scenetype, sizeof(int), 0);
						if (retval == SOCKET_ERROR)
						{
							err_display("recv()");
							break;
						}
						printf("%dbyte Received. SceneType : %d\n", retval, scenetype);
						//if (csinfo2.go_to_wr)
					}

				}
			}
			else if (scenetype == 1)
			{
				

				printf("�߽� �Ϸ�\n");
				if (g_waitRoomCharInfo.size[tempid] != -1) {
					retval = send(client_sock, (char*)&g_waitRoomCharInfo, sizeof(g_waitRoomCharInfo), 0);
					if (retval == SOCKET_ERROR)
					{
						err_display("send()");
						break;
					}
					if (g_waitRoomSel.id[tempid] != -1) 
					{
						m_waitRoomSel.id[tempid] = tempid;
						m_waitRoomSel.selected[tempid] = true;
						m_waitRoomSel.logoBitmap[tempid] = 124;
						m_waitRoomSel.buttonDownBitmap[tempid] = 122;
					}
					retval = send(client_sock, (char*)&m_waitRoomSel, sizeof(m_waitRoomSel), 0);
					if (retval == SOCKET_ERROR) { err_display("send()"); break; }
					if (m_waitRoomSel.id[tempid] != -1 && (m_StopOneID == false)) {
						m_StopOneID = true;
						++g_nextSceneCnt;
					}
					if (g_nextSceneCnt >= MAX_PLAYER) {
						for (int i = 0; i < MAX_PLAYER; ++i)
						{
							m_waitRoomSel.id[i] = g_waitRoomSel.id[i];
							m_waitRoomSel.selected[i] = g_waitRoomSel.selected[i];
							m_waitRoomSel.logoBitmap[i] = g_waitRoomSel.logoBitmap[i];
							m_waitRoomSel.buttonDownBitmap[i] = g_waitRoomSel.buttonDownBitmap[i];
						}
						isW = false;
					}
					else
						isW = true;
				}
				retval = send(client_sock, (char*)&isW, sizeof(bool), 0);
				if (retval == SOCKET_ERROR)
				{
					err_display("send()");
					break;
				}
				if (!isW) {
					retval = send(client_sock, (char*)&m_waitRoomSel, sizeof(m_waitRoomSel), 0);
					if (retval == SOCKET_ERROR) { err_display("send()"); break; }
					scenetype = 2;
					++ready_people;
					if (ready_people >= MAX_PLAYER)
					{
						
						
						m_StopTwoID = false; 
						m_StopOneID = false;
					}
				}
				//printf("%d", csinfo.character_type);


				//if (wrinfo.game_ready)
				//	scenetype = 2;
			}
			else if (scenetype == 2)
			{
				/*
				retval = send(client_sock, (char*)&cinfo2, sizeof(cinfo2), 0);
				if (retval == SOCKET_ERROR)
				{
					err_display("send()");
					break;
				}
				*/
				printf("�� ���Ӿ��̿�\n\n");
				//�ڵ��� �̵�
				carinfo.posY[0] = (carinfo.posY[0] + 2) % (u_short)420;
				carinfo.posY[1] = (carinfo.posY[1] + 1) % (u_short)420;
				carinfo.posY[2] = (carinfo.posY[2] + (u_short)3) % (u_short)420;
				carinfo.posY[3] = (carinfo.posY[3] + (u_short)4) % (u_short)420;
				carinfo.posY[4] = (carinfo.posY[4] - (u_short)5);
				carinfo.posY[5] = (carinfo.posY[5] - (u_short)1);
				carinfo.posY[6] = (carinfo.posY[6] - (u_short)2);
				carinfo.posY[7] = (carinfo.posY[7] - (u_short)3);

				for (int i = 0; i < 4; ++i) {
					if (carinfo.posY[i + 4] <= 0) {
						carinfo.posY[i + 4] = 420;
					}
					carinfo2.posY[i] = (carinfo.posY[i]);
					carinfo2.posY[i + 4] = (carinfo.posY[i + 4]);

				}
				retval = send(client_sock, (char*)&carinfo2, sizeof(carinfo2), 0);
				if (retval == SOCKET_ERROR)
				{
					err_display("send()");
					break;
				}
				printf("%d����Ʈ �߽�, carPosx : %d\n", retval, carinfo.posY[0]);
				retval = recv(client_sock, (char*)&cinfo, sizeof(cinfo), 0);
				if (retval == SOCKET_ERROR)
				{
					err_display("send()");
					break;
				}
				if (cinfo.id == 0) {
					g_cinfo[0].char_pos.x = cinfo.char_pos.x;
					g_cinfo[0].char_pos.y = cinfo.char_pos.y;
					g_cinfo[0].life = cinfo.life;
					g_cinfo[0].score = cinfo.score;

				}
				else {
					g_cinfo[1].char_pos.x = cinfo.char_pos.x;
					g_cinfo[1].char_pos.y = cinfo.char_pos.y;
					g_cinfo[1].life = cinfo.life;
					g_cinfo[1].score = cinfo.score;

				}
				printf("%d����Ʈ ����, ID�� %d, �������� (%d,%d)\n\n", retval, cinfo.id,cinfo.char_pos.x,cinfo.char_pos.y);
				if (cinfo.id == 0)
					retval = send(client_sock, (char*)&g_cinfo[1], sizeof(cinfo), 0);
				else
					retval = send(client_sock, (char*)&g_cinfo[0], sizeof(cinfo), 0);
				if (retval == SOCKET_ERROR)
				{
					err_display("send()");
					break;
				}
				if (cinfo.id == 0)
					printf("%d����Ʈ �߽�, ���� ID�� %d\n\n", retval, g_cinfo[1].id);
				else
					printf("%d����Ʈ �߽�, ���� ID�� %d\n\n", retval, g_cinfo[0].id);

				if (IsCollide(cinfo, carinfo)) {
					if(cinfo.life>0)
						cinfo.life = cinfo.life - 1;
				}
				retval = send(client_sock, (char*)&cinfo.life, sizeof(int), 0);
				if (retval == SOCKET_ERROR)
				{
					err_display("send()");
					break;
				}
				printf("%d����Ʈ �߽�, ���� ü���� %d\n\n", retval, cinfo.life);
				/*
				retval = send(client_sock, (char*)&carinfo2, sizeof(carinfo2), 0);
				if (retval == SOCKET_ERROR)
				{
					err_display("send()");
					break;
				}
				printf("%d����Ʈ �߽�, carPosx : %d\n", retval,carinfo.posY[0]);
				retval = recv(client_sock, (char*)&cinfo2, sizeof(cinfo2), 0);
				if (retval == SOCKET_ERROR)
				{
					err_display("recv()");
					break;
				}

				printf("ID : %d\n", cinfo2.id);
				if (IsCollide(cinfo.char_pos, carinfo))
				{

					cinfo2.life = cinfo2.life - 1;
				}
				printf("%d����Ʈ ���ſϷ� : %d \n",retval, cinfo2.id);
				*/
			}
		}
		/*
		if (csinfo.character_type != 0) {
			packet_Folder.packet_Cs[0].go_to_wr = true;
			//retval = send(client_sock0, (char*)&packet_Folder.packet_Cs[0], sizeof(Character_Select), 0);
			retval = send(client_sock0, (char*)&csinfo, sizeof(Character_Select), 0);
			

		}
		else
		{
			packet_Folder.packet_Cs[0].go_to_wr = false;
			retval = send(client_sock0, (char*)&packet_Folder.packet_Cs[0], sizeof(Character_Select), 0);
			//retval = send(client_sock0, (char*)&addrlen, sizeof(int), 0);
		}
		if (retval == SOCKET_ERROR)
		{
			err_display("send()");
			break;
		}
		printf("id :%d �߽� �Ϸ�\n", csinfo.id);
		retval = recv(client_sock0, (char*)&csinfo, sizeof(csinfo), 0);
		if (retval == SOCKET_ERROR)
		{
			err_display("recv()");
			break;
		}
		//printf("%d", csinfo.character_type);
		
			
		printf("���ſϷ� : What did you choose : %d\n", csinfo.character_type);
		
		*/
		//SetEvent(hCharacterSelectEvent);
	}

	//packet_Folder.SetC_SInfo(csinfo.id, csinfo.character_type);
	//csinfo.go_to_wr = true;
	//retval = send(client_sock0, (char*)&csinfo, sizeof(csinfo), 0);
	/*
	if (inet_ntoa(clientaddr.sin_addr) == inet_ntoa(clientaddr1.sin_addr)) {
		sendid = 2;
	}
	else if(inet_ntoa(clientaddr.sin_addr) == inet_ntoa(clientaddr2.sin_addr)) {
		sendid = 1;
	}
	*/


	


	
	
	//closesocket()
	closesocket(client_sock);
	printf("[TCP ����] Ŭ���̾�Ʈ ����: IP �ּ� =%s,��Ʈ ��ȣ=%d\n", inet_ntoa(clientaddr.sin_addr), ntohs(clientaddr.sin_port));

	return 0;
}
DWORD WINAPI Player2Thread(LPVOID arg)
{
	SOCKET client_sock = (SOCKET)arg;
	int retval;
	SOCKADDR_IN clientaddr;
	int addrlen;
	//PacketClass packet_Party;
	Game_Info gameinfo;
	int count = 0;
	Character_Select csinfo2;
	Character_Select csinfo3;
	CharacterInfo cinfo;
	//CharacterInfo cinfo2;

	CarObjectInfo carinfo2;
	Wait_Room wrinfo;
	Wait_Room wrinfo2;
	int scenetype = 0;
	//ZeroMemory(&csinfo, sizeof(csinfo));
	//retval = WaitForSingleObject(hSendEvent, INFINITE);
	//Ŭ���̾�Ʈ ���� ���
	addrlen = sizeof(clientaddr);

	getpeername(client_sock, (SOCKADDR*)&clientaddr, &addrlen);


	csinfo2.go_to_wr = false;
	csinfo2.id = sendid + 1;

	int tempid;
	tempid = 1;
	sendid++;
	cinfo.packType = PACK_TYPE::CHARACTER_INFO;
	cinfo.life = 20;
	cinfo.score = 0;

	packet_Folder.InitializePacket();
	if (tempid == 1) {
		//	cinfo2.char_pos.x = htonl(60);
		//	cinfo2.char_pos.y = htonl(400);
		cinfo.char_pos.x = 640;
		cinfo.char_pos.y = 400;
	}
	else {
		//	cinfo2.char_pos.x = 640;
		//	cinfo2.char_pos.y = 400;
		cinfo.char_pos.x = 60;
		cinfo.char_pos.y = 400;
	}

	ZeroMemory(&carinfo, sizeof(carinfo));
	for (int i = 0; i < 8; ++i)
		carinfo.posY[i] = 100;

	int count5 = 0;

	int selected = -1;
	bool isR = true;
	while (1)
	{
		if (count == 15) {
			
			retval = send(client_sock, (char*)&scenetype, sizeof(int), 0);
			if (retval == SOCKET_ERROR)
			{
				err_display("send()");
				break;
			}

			printf("%d����Ʈ ����, ���� ���� %d��°��\n", retval, scenetype + 1);
			if (scenetype == 0)
			{
				if (scenetype != 1 && scenetype != 2) {
					retval = send(client_sock, (char*)&tempid, sizeof(int), 0);
					if (retval == SOCKET_ERROR)
					{
						err_display("send()");
						break;
					}
					retval = send(client_sock, (char*)&selected, sizeof(int), 0);
					if (retval == SOCKET_ERROR)
					{
						err_display("send()");
						break;
					}
					printf("%d����Ʈ ����, %d�� ������ϴ�. \n", retval, selected);
					retval = recv(client_sock, (char*)&isR, sizeof(bool), 0);
					if (retval == SOCKET_ERROR)
					{
						err_display("recv()");
						break;
					}
					printf("%d����Ʈ ����, �����? %d \n", retval, isR);

				}
				if (!isR) {

					retval = recv(client_sock, (char*)&csinfo3, sizeof(csinfo3), 0);
					if (retval == SOCKET_ERROR)
					{
						err_display("recv()");
						break;
					}
					//printf("%d", csinfo.character_type);
					//count5++;
					printf("%d��° ���ſϷ� : What did you choose : %d, %d����Ʈ�� �����߽��ϴ�.\n", count5, csinfo3.id, retval);
					//retval = send(client_sock, (char*)&csinfo2, sizeof(csinfo3), 0);
					retval = send(client_sock, (char*)&scenetype, sizeof(int), 0);
					if (retval == SOCKET_ERROR)
					{
						err_display("send()");
						break;
					}
					//				if (csinfo3.character_type != 0) {
					//					csinfo2.go_to_wr = true;
					//					csinfo2.character_left = csinfo3.character_type;
					//					printf("�߽� �غ� �Ϸ�\n");

					//				}
					retval = recv(client_sock, (char*)&scenetype, sizeof(int), 0);
					if (retval == SOCKET_ERROR)
					{
						err_display("recv()");
						break;
					}
					printf("%dbyte Received. SceneType : %d\n", retval, scenetype);
					//if (csinfo2.go_to_wr)
				}

			}
			else if (scenetype == 1)
			{
				retval = send(client_sock, (char*)&wrinfo, sizeof(wrinfo), 0);
				if (retval == SOCKET_ERROR)
				{
					err_display("send()");
					break;
				}

				printf("�߽� �Ϸ�\n");
				retval = recv(client_sock, (char*)&wrinfo2, sizeof(wrinfo2), 0);
				if (retval == SOCKET_ERROR)
				{
					err_display("recv()");
					break;
				}
				//printf("%d", csinfo.character_type);


				if (wrinfo.game_ready)
					scenetype = 2;
			}
			else if (scenetype == 2)
			{
				/*
				retval = send(client_sock, (char*)&cinfo2, sizeof(cinfo2), 0);
				if (retval == SOCKET_ERROR)
				{
				err_display("send()");
				break;
				}
				*/
				printf("�� ���Ӿ��̿�\n\n");
				//�ڵ��� �̵�
				carinfo.posY[0] = (carinfo.posY[0] + 2) % (u_short)420;
				carinfo.posY[1] = (carinfo.posY[1] + 1) % (u_short)420;
				carinfo.posY[2] = (carinfo.posY[2] + (u_short)3) % (u_short)420;
				carinfo.posY[3] = (carinfo.posY[3] + (u_short)4) % (u_short)420;
				carinfo.posY[4] = (carinfo.posY[4] - (u_short)5);
				carinfo.posY[5] = (carinfo.posY[5] - (u_short)1);
				carinfo.posY[6] = (carinfo.posY[6] - (u_short)2);
				carinfo.posY[7] = (carinfo.posY[7] - (u_short)3);

				for (int i = 0; i < 4; ++i) {
					if (carinfo.posY[i + 4] <= 0) {
						carinfo.posY[i + 4] = 420;
					}
					carinfo2.posY[i] = (carinfo.posY[i]);
					carinfo2.posY[i + 4] = (carinfo.posY[i + 4]);

				}
				retval = send(client_sock, (char*)&carinfo2, sizeof(carinfo2), 0);
				if (retval == SOCKET_ERROR)
				{
					err_display("send()");
					break;
				}
				printf("%d����Ʈ �߽�, carPosx : %d\n", retval, carinfo.posY[0]);
				retval = recv(client_sock, (char*)&cinfo, sizeof(cinfo), 0);
				if (retval == SOCKET_ERROR)
				{
					err_display("send()");
					break;
				}
				if (cinfo.id == 0) {
					g_cinfo[0].char_pos.x = cinfo.char_pos.x;
					g_cinfo[0].char_pos.y = cinfo.char_pos.y;
					g_cinfo[0].life = cinfo.life;
					g_cinfo[0].score = cinfo.score;

				}
				else {
					g_cinfo[1].char_pos.x = cinfo.char_pos.x;
					g_cinfo[1].char_pos.y = cinfo.char_pos.y;
					g_cinfo[1].life = cinfo.life;
					g_cinfo[1].score = cinfo.score;

				}
				printf("%d����Ʈ ����, ID�� %d\n\n", retval, cinfo.id);
				if (cinfo.id == 0)
					retval = send(client_sock, (char*)&g_cinfo[1], sizeof(cinfo), 0);
				else
					retval = send(client_sock, (char*)&g_cinfo[0], sizeof(cinfo), 0);
				if (retval == SOCKET_ERROR)
				{
					err_display("send()");
					break;
				}
				if (cinfo.id == 0)
					printf("%d����Ʈ �߽�, ���� ID�� %d\n\n", retval, g_cinfo[1].id);
				else
					printf("%d����Ʈ �߽�, ���� ID�� %d\n\n", retval, g_cinfo[0].id);
				/*
				retval = send(client_sock, (char*)&carinfo2, sizeof(carinfo2), 0);
				if (retval == SOCKET_ERROR)
				{
				err_display("send()");
				break;
				}
				printf("%d����Ʈ �߽�, carPosx : %d\n", retval,carinfo.posY[0]);
				retval = recv(client_sock, (char*)&cinfo2, sizeof(cinfo2), 0);
				if (retval == SOCKET_ERROR)
				{
				err_display("recv()");
				break;
				}

				printf("ID : %d\n", cinfo2.id);
				if (IsCollide(cinfo.char_pos, carinfo))
				{

				cinfo2.life = cinfo2.life - 1;
				}
				printf("%d����Ʈ ���ſϷ� : %d \n",retval, cinfo2.id);
				*/
			}
		}
		
		//SetEvent(hCharacterSelectEvent);
	}








	//closesocket()
	closesocket(client_sock);
	printf("[TCP ����] Ŭ���̾�Ʈ ����: IP �ּ� =%s,��Ʈ ��ȣ=%d\n", inet_ntoa(clientaddr.sin_addr), ntohs(clientaddr.sin_port));

	return 0;
}
/*
DWORD WINAPI SendThread(LPVOID arg)
{
	SOCKET send_sock = (SOCKET)arg;
	SOCKADDR_IN clientaddr;
	Character_Select csinfo;
	int addrlen;
	int retval;
	addrlen = sizeof(clientaddr);
	getpeername(send_sock, (SOCKADDR*)&clientaddr, &addrlen);
	csinfo.packType = PACK_TYPE::SELECT_ROOM;
	csinfo.character_type = 0;
	csinfo.go_to_wr = false;
	
	csinfo.character_left = packet_Folder.packet_Cs[0].character_left;
	csinfo.id = 0;
	retval = WaitForSingleObject(hCharacterSelectEvent, INFINITE);
	if (sendtype == PACK_TYPE::SELECT_ROOM) {
		if (sendid == 1) {
			//retval = send(client_sock, (char*)&packet_Folder.packet_Cs, sizeof(packet_Folder.packet_Cs), 0);
			sendid = 0;
			
		}
		else if (sendid == 2) {
			//retval = send(client_sock, (char*)&packet_Folder.packet_Cs, sizeof(packet_Folder.packet_Cs), 0);
			sendid = 0;
			
		}

	}
	SetEvent(hSendEvent);
	return 0;
}
*/
int main(int argc, char* argv[]) 
{
	//���ϰ����Լ��� ������ �� return value�� ������ִ� �Լ�
	int retval;
	//������ ���� ���� int�� ����
	
	int scenetype = 0;
	//���� �ʱ�ȭ
	WSADATA wsa;
	if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
		return 1;
	int count = 0;
	Character_Select csinfo2;
	Character_Select csinfo3;
	CharacterInfo cinfo;
	CharacterInfo cinfo2;
	CarObjectInfo carinfo;
	CarObjectInfo carinfo2;
	Wait_Room wrinfo;
	Wait_Room wrinfo2;
	printf("sizeof short : %d, %d\n", sizeof(u_short), sizeof(short));
	//socket()
	SOCKET sock = socket(AF_INET, SOCK_STREAM, 0);

	SOCKADDR_IN clientaddr1;
	
	if (sock == INVALID_SOCKET)
		err_quit("socket()");
	SOCKET client_sock;
	//���� ����ϴ� ��Ŷ ����ü �ʱⰪ ����
	printf("CharcterInfo size: %dByte\n", sizeof(CharacterInfo));
	printf("CarObjectInfo size: %dByte\n", sizeof(CarObjectInfo));
	printf("ItemObjectInfo size: %dByte\n", sizeof(ItemObjectInfo));
	printf("ObstacleObjectInfo size: %dByte\n", sizeof(ObstacleObjectInfo));
	printf("Game_Info size: %dByte\n", sizeof(Game_Info));
	printf("Character_Select size: %dByte\n", sizeof(Character_Select));
	printf("Wait_Room size: %dByte\n", sizeof(Wait_Room));
	printf("TimeInfo size: %dByte\n", sizeof(TimeInfo));
	g_cinfo[0].id = 0;
	g_cinfo[1].id = 1;
	g_cinfo[0].char_pos.x = 60;
	g_cinfo[0].char_pos.y = 400;
	g_cinfo[1].char_pos.x = 640;
	g_cinfo[1].char_pos.y = 400;

	packet_Folder.InitializePacket();
	//bind()
	SOCKADDR_IN serveraddr;
	ZeroMemory(&serveraddr, sizeof(serveraddr));
	serveraddr.sin_family = AF_INET;
	serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);
	serveraddr.sin_port = htons(SERVERPORT);
	retval = bind(sock, (SOCKADDR *)&serveraddr, sizeof(serveraddr));
	if (retval == SOCKET_ERROR) 
		err_quit("bind()");
	retval = listen(sock, SOMAXCONN);
	if (retval == SOCKET_ERROR)
		err_quit("listen()");

	
	
	

	

	ZeroMemory(&clientaddr1, sizeof(clientaddr1));
	
	//hCharacterSelectEvent = CreateEvent(NULL, FALSE, TRUE, NULL);
	//hSendEvent = CreateEvent(NULL, FALSE, FALSE, NULL);

	int addrlen;
	HANDLE hThread;

	while (1) 
	{
		// accept()
		addrlen = sizeof(clientaddr1);
		

		
		client_sock= accept(sock, (SOCKADDR *)&clientaddr1, &addrlen);
		if (client_sock == INVALID_SOCKET)
		{
			err_display("accept()");
			break;
		}
		// ������ Ŭ���̾�Ʈ ���� ���

		printf("\n[TCP ����] Ŭ���̾�Ʈ ����: IP �ּ�=%s, ��Ʈ ��ȣ=%d\n", inet_ntoa(clientaddr1.sin_addr), ntohs(clientaddr1.sin_port));

		csinfo2.go_to_wr = false;
//		csinfo2.character_left = 0;
		csinfo2.id = sendid + 1;
		//sendid++;
		cinfo.packType = PACK_TYPE::CHARACTER_INFO;
		cinfo.life = 20;
		cinfo.score = 0;
		cinfo2.life = 20;
		ZeroMemory(&carinfo, sizeof(carinfo));
		for (int i = 0; i < 8; ++i)
			carinfo.posY[i] = 100;

		/*
		while (1) {
			
			if (scenetype == 0)
			{
				retval = send(client_sock, (char*)&csinfo2, sizeof(csinfo2), 0);
				if (retval == SOCKET_ERROR)
				{
					err_display("send()");
					break;
				}

				printf("id :%d �߽� �Ϸ�\n", csinfo2.id);
				retval = recv(client_sock, (char*)&csinfo3, sizeof(csinfo3), 0);
				if (retval == SOCKET_ERROR)
				{
					err_display("recv()");
					break;
				}
				//printf("%d", csinfo.character_type);
				printf("���ſϷ� : What did you choose : %d\n", csinfo3.character_type);

				if (csinfo3.character_type != 0) {
					csinfo2.go_to_wr = true;
					csinfo2.character_left = csinfo3.character_type;
					
				}
				if(csinfo2.go_to_wr)
					scenetype = 2;
			}
			else if (scenetype == 1)
			{
				retval = send(client_sock, (char*)&wrinfo, sizeof(wrinfo), 0);
				if (retval == SOCKET_ERROR)
				{
					err_display("send()");
					break;
				}

				printf("�߽� �Ϸ�\n");
				retval = recv(client_sock, (char*)&wrinfo2, sizeof(wrinfo2), 0);
				if (retval == SOCKET_ERROR)
				{
					err_display("recv()");
					break;
				}
				//printf("%d", csinfo.character_type);
				
				
				if (wrinfo.game_ready)
					scenetype = 2;
			}
			else if (scenetype == 2)
			{
				//MoveCar(carinfo);
				//retval = send(client_sock, (char*)&cinfo, sizeof(cinfo), 0);
				//if (retval == SOCKET_ERROR)
				//{
				//	err_display("send()");
				//	break;
				//}
				
				carinfo.posY[0] = (carinfo.posY[0] + (u_short)2) % (u_short)420;
				carinfo.posY[1] = (carinfo.posY[1] + (u_short)1) % (u_short)420;
				carinfo.posY[2] = (carinfo.posY[2] + (u_short)3) % (u_short)420;
				carinfo.posY[3] = (carinfo.posY[3] + (u_short)4) % (u_short)420;
				carinfo.posY[4] = (carinfo.posY[4] - (u_short)5);
				carinfo.posY[5] = (carinfo.posY[5] - (u_short)1);
				carinfo.posY[6] = (carinfo.posY[6] - (u_short)2);
				carinfo.posY[7] = (carinfo.posY[7] - (u_short)3);
				
				for (int i = 0; i < 4; ++i) {
					if (carinfo.posY[i + 4] <= 0) {
						carinfo.posY[i + 4] = 420;
					}
					carinfo2.posY[i] = htons(carinfo.posY[i]);
					carinfo2.posY[i+4] = htons(carinfo.posY[i+4]);

				}
				retval = send(client_sock, (char*)&carinfo2, sizeof(carinfo2),0);
				if (retval == SOCKET_ERROR)
				{
					err_display("send()");
					break;
				}
				printf("carPosx : %d\n", carinfo.posY[0]);
				retval = recv(client_sock, (char*)&cinfo2, sizeof(cinfo2), 0);
				if (retval == SOCKET_ERROR)
				{
					err_display("recv()");
					break;
				}
				if (IsCollide(cinfo.char_pos, carinfo))
				{
					
					cinfo2.life = cinfo2.life - 1;
				}
				printf("���ſϷ� : %d\n", cinfo2.id);
			}
		}*/
		if (count == 0) {
			hThread = CreateThread(NULL, 0, Player1Thread, (LPVOID)client_sock, 0, NULL);

			if (hThread == NULL) {
				closesocket(client_sock);
			}
			else {
				CloseHandle(hThread);
			}
		}
		else {
			hThread = CreateThread(NULL, 0, Player2Thread, (LPVOID)client_sock, 0, NULL);

			if (hThread == NULL) {
				closesocket(client_sock);
			}
			else {
				CloseHandle(hThread);
			}
		}
		//closesocket(client_sock);
		
		
		
		count++;
		
	}
	//CloseHandle(hCharacterSelectEvent);
	//CloseHandle(hSendEvent);

	closesocket(sock);
	WSACleanup();
	return 0;
}


void MoveCar(CarObjectInfo car) {

	//car.posY[0] = (car.posY[0] + 3) % 420;
	car.posY[0] = 150;
	car.posY[1] = (car.posY[1] + 4) % 420;
	car.posY[2] = (car.posY[2] + 2) % 420;
	car.posY[3] = (car.posY[3] + 1) % 420;
	car.posY[4] = (car.posY[4] - 1) % 420;
	car.posY[5] = (car.posY[5] - 2) % 420;
	car.posY[6] = (car.posY[6] - 2) % 420;
	car.posY[7] = (car.posY[7] - 5) % 420;


}
bool IsCollide(CharacterInfo ch, CarObjectInfo car) {
	for (int i = 0; i < 8; ++i)
	{

		bool col1 = (ch.char_pos.x + 35 > carposx[i] - 25);
		bool col2 = (ch.char_pos.x - 35 < carposx[i] + 25);
		bool col3 = (ch.char_pos.y + 35 > car.posY[i] - 40);
		bool col4 = (ch.char_pos.y - 35 < car.posY[i] + 40);
		if ((col1 && col2) && (col3 && col4))
		{
			cout << "�浹" << endl;
			return true;
		}

		else
			return false;
	}
	return false;
}