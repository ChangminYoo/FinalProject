#pragma comment(lib,"ws2_32")
#pragma warning(disable:4996)
#include <WinSock2.h>
#include <stdlib.h>
#include <stdio.h>
#include <io.h>
#include <fcntl.h>
#include <vector>
#include "stdafx.h"
#define SERVERIP "127.0.0.1"
#define SERVERPORT 9000
#define BUFSIZE 512

//���� �Լ� ���� ��� �� ����

HANDLE hCharacterSelectEvent;
HANDLE hSendEvent;
SOCKET client_sock[2];
SOCKADDR_IN clientaddr1;
SOCKADDR_IN clientaddr2;
//�������� ����ϰ� �ִ� ��Ŷ���� ����
PacketClass packet_Folder;
int sendtype = 0;
int sendid=0;
void err_quit(char* msg) 
{
	LPVOID lpMsgBuf;
	FormatMessage(
		FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
		NULL, WSAGetLastError(),
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR)&lpMsgBuf, 0, NULL);
	MessageBox(NULL, (LPCTSTR)lpMsgBuf, msg, MB_ICONERROR);
	LocalFree(lpMsgBuf);
	exit(1);
}

void err_display(char *msg)
{
	LPVOID lpMsgBuf;
	FormatMessage(
		FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
		NULL, WSAGetLastError(),
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR)&lpMsgBuf, 0, NULL);
	printf("[%s] %s", msg, (char *)lpMsgBuf);
	LocalFree(lpMsgBuf);
}
//����� ���� ������ ���� �Լ�
int recvn(SOCKET s, char* buf, int len, int flags) {
	int received;
	char* ptr = buf;
	int left = len;
	while (left > 0) {
		received = recv(s, ptr, left, flags);
		if (received == SOCKET_ERROR)
			return SOCKET_ERROR;
		else if (received == 0)
			break;
		left -= received;
		ptr += received;
	}
	return (len - left);


}


DWORD WINAPI Player1Thread(LPVOID arg)
{
	SOCKET client_sock0 = (SOCKET)arg;
	int retval;
	SOCKADDR_IN clientaddr;
	int addrlen;
	//PacketClass packet_Party;
	CharacterInfo chrinfo;
	CarObjectInfo carinfo;
	ItemObjectInfo iteminfo;
	ObstacleObjectInfo objinfo;
	TimeInfo timeinfo;
	Wait_Room wrinfo;
	Character_Select csinfo;
	Game_Info gameinfo;
	ZeroMemory(&csinfo, sizeof(csinfo));
	retval = WaitForSingleObject(hSendEvent, INFINITE);
	//Ŭ���̾�Ʈ ���� ���
	addrlen = sizeof(clientaddr);
	
	getpeername(client_sock0, (SOCKADDR*)&clientaddr, &addrlen);
	
	csinfo.packType = PACK_TYPE::SELECT_ROOM;
	csinfo.character_type = 0;
	csinfo.go_to_wr = false;
	csinfo.character_left = 0;
	csinfo.id=0;
	
	retval = send(client_sock0, (char*)&csinfo, sizeof(csinfo), 0);
	if (retval == SOCKET_ERROR)
	{
		err_display("send()");
		return 0;
	}

	retval = recvn(client_sock0, (char*)&csinfo, sizeof(csinfo), 0);
	if (retval == SOCKET_ERROR)
	{
		err_display("recv()");
		return 0;
	}
	packet_Folder.SetC_SInfo(csinfo.id, csinfo.character_type);
	csinfo.go_to_wr = true;
	retval = send(client_sock0, (char*)&csinfo, sizeof(csinfo), 0);
	if (inet_ntoa(clientaddr.sin_addr) == inet_ntoa(clientaddr1.sin_addr)) {
		sendid = 2;
	}
	else if(inet_ntoa(clientaddr.sin_addr) == inet_ntoa(clientaddr2.sin_addr)) {
		sendid = 1;
	}
	sendtype = PACK_TYPE::SELECT_ROOM;

	SetEvent(hCharacterSelectEvent);


	
	
	//closesocket()
	closesocket(client_sock0);
	printf("[TCP ����] Ŭ���̾�Ʈ ����: IP �ּ� =%s,��Ʈ ��ȣ=%d\n", inet_ntoa(clientaddr.sin_addr), ntohs(clientaddr.sin_port));

	return 0;
}
DWORD WINAPI SendThread(LPVOID arg)
{
	SOCKET send_sock = (SOCKET)arg;
	SOCKADDR_IN clientaddr;
	Character_Select csinfo;
	int addrlen;
	int retval;
	addrlen = sizeof(clientaddr);
	getpeername(send_sock, (SOCKADDR*)&clientaddr, &addrlen);
	csinfo.packType = PACK_TYPE::SELECT_ROOM;
	csinfo.character_type = 0;
	csinfo.go_to_wr = false;
	
	csinfo.character_left = packet_Folder.packet_Cs[0].character_left;
	csinfo.id = 0;
	retval = WaitForSingleObject(hCharacterSelectEvent, INFINITE);
	if (sendtype == PACK_TYPE::SELECT_ROOM) {
		if (sendid == 1) {
			retval = send(client_sock[0], (char*)&packet_Folder.packet_Cs, sizeof(packet_Folder.packet_Cs), 0);
			sendid = 0;
			SetEvent(hSendEvent);
		}
		else if (sendid == 2) {
			retval = send(client_sock[1], (char*)&packet_Folder.packet_Cs, sizeof(packet_Folder.packet_Cs), 0);
			sendid = 0;
			SetEvent(hSendEvent);
		}

	}
	return 0;
}

int main(int argc, char* argv[]) 
{
	//���ϰ����Լ��� ������ �� return value�� ������ִ� �Լ�
	int retval;
	//������ ���� ���� int�� ����
	int count = 0; 
	//���� �ʱ�ȭ
	WSADATA wsa;
	if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
		return 1;
	
	//socket()
	SOCKET sock = socket(AF_INET, SOCK_STREAM, 0);
	if (sock == INVALID_SOCKET)
		err_quit("socket()");

	//���� ����ϴ� ��Ŷ ����ü �ʱⰪ ����
	printf("CharcterInfo size: %dByte\n", sizeof(CharacterInfo));
	printf("CarObjectInfo size: %dByte\n", sizeof(CarObjectInfo));
	printf("ItemObjectInfo size: %dByte\n", sizeof(ItemObjectInfo));
	printf("ObstacleObjectInfo size: %dByte\n", sizeof(ObstacleObjectInfo));
	printf("Game_Info size: %dByte\n", sizeof(Game_Info));
	printf("Character_Select size: %dByte\n", sizeof(Character_Select));
	printf("Wait_Room size: %dByte\n", sizeof(Wait_Room));
	printf("TimeInfo size: %dByte\n", sizeof(TimeInfo));
	packet_Folder.InitializePacket();
	//bind()
	SOCKADDR_IN serveraddr;
	ZeroMemory(&serveraddr, sizeof(serveraddr));
	serveraddr.sin_family = AF_INET;
	serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);
	serveraddr.sin_port = htons(SERVERPORT);
	retval = bind(sock, (SOCKADDR *)&serveraddr, sizeof(serveraddr));
	if (retval == SOCKET_ERROR) 
		err_quit("bind()");
	retval = listen(sock, SOMAXCONN);
	if (retval == SOCKET_ERROR)
		err_quit("listen()");

	
	
	

	ZeroMemory(&client_sock, sizeof(client_sock));
	

	ZeroMemory(&clientaddr1, sizeof(clientaddr1));
	ZeroMemory(&clientaddr2, sizeof(clientaddr2));
	hCharacterSelectEvent = CreateEvent(NULL, FALSE, TRUE, NULL);
	hSendEvent = CreateEvent(NULL, FALSE, FALSE, NULL);

	int addrlen;
	HANDLE hThread[3];
	while (1) 
	{
		// accept()
		addrlen = sizeof(clientaddr1);
		addrlen = sizeof(clientaddr2);

		if (count == 0) {
			client_sock[count] = accept(sock, (SOCKADDR *)&clientaddr1, &addrlen);
			if (client_sock[count] == INVALID_SOCKET)
			{
				err_display("accept()");
				break;
			}
			// ������ Ŭ���̾�Ʈ ���� ���

			printf("\n[TCP ����] Ŭ���̾�Ʈ ����: IP �ּ�=%s, ��Ʈ ��ȣ=%d\n", inet_ntoa(clientaddr1.sin_addr), ntohs(clientaddr1.sin_port));
			hThread[0] = CreateThread(NULL, 0, Player1Thread, (LPVOID)client_sock, 0, NULL);
			if (hThread[0] == NULL) {
				closesocket(client_sock[count]);
			}
			else {
				CloseHandle(hThread[0]);
			}
			closesocket(client_sock[count]);
		}
		else if(count==1){
			client_sock[count] = accept(sock, (SOCKADDR *)&clientaddr2, &addrlen);
			if (client_sock[count] == INVALID_SOCKET)
			{
				err_display("accept()");
				break;
			}
			// ������ Ŭ���̾�Ʈ ���� ���

			printf("\n[TCP ����] Ŭ���̾�Ʈ ����: IP �ּ�=%s, ��Ʈ ��ȣ=%d\n", inet_ntoa(clientaddr2.sin_addr), ntohs(clientaddr2.sin_port));
			hThread[1] = CreateThread(NULL, 0, Player1Thread, (LPVOID)client_sock[count], 0, NULL);
			if (hThread[1] == NULL) {
				closesocket(client_sock[count]);
			}
			else {
				CloseHandle(hThread[1]);
			}
			closesocket(client_sock[count]);

		}
		hThread[2] = CreateThread(NULL, 0, SendThread, NULL, 0, NULL);
		count++;
		
	}
	CloseHandle(hCharacterSelectEvent);
	CloseHandle(hSendEvent);

	closesocket(sock);
	WSACleanup();
	return 0;
}


