#pragma once
#pragma once
#include <windows.h>
#include <math.h>
#include <time.h>
#include <string>
#include <stdlib.h>
#include <conio.h>
#include <mmsystem.h>
#include <iostream>
#include <map>
#include <vector>
#include <random>

using namespace std;




struct Pos
{
	int x;
	int y;
};
//��ȣ ��� func\n{} ������ �� 

//ĳ���� ���� ����ü

enum PACK_TYPE
{
	SELECT_ROOM,
	WAIT_ROOM,
	STAGE_TIME,
	CHARACTER_INFO,
	OBSTACLE_CAR,
	OBSTACLE_LASER,
	ITEM_CLICK,
	GAME_OVER
};
#pragma pack(1)
struct CharacterInfo
{

	PACK_TYPE packType = PACK_TYPE::CHARACTER_INFO;
	union
	{
		Pos char_pos;
		int score;
		u_short id;
		int life;
	}S_un;
};
#pragma pack()

//�ڵ��� ��ֹ� ���� ����ü
#pragma pack(1)
struct CarObjectInfo
{

	PACK_TYPE packType = PACK_TYPE::OBSTACLE_CAR;
	int posY[8];

};
#pragma pack()

#pragma pack(1)
struct ItemObjectInfo
{

	PACK_TYPE packType = PACK_TYPE::ITEM_CLICK;
	union
	{
		Pos item_pos;
		bool is_alive;
		u_short id;

	}C_un;
};
#pragma pack()

#pragma pack(1)
struct ObstacleObjectInfo
{

	PACK_TYPE packType = PACK_TYPE::OBSTACLE_LASER;
	union
	{
		bool is_alive;
		bool is_break;
		u_short id;
		float clearTime;

	}C_un;
};
#pragma pack()

//�ð� ���� ����ü
#pragma pack(1)
struct TimeInfo
{
	PACK_TYPE packType = PACK_TYPE::STAGE_TIME;
	double game_Play_Time;
};
#pragma pack()


//��� �� ���� ���� ����ü
#pragma pack(1)
struct Wait_Room
{
	PACK_TYPE packType = PACK_TYPE::WAIT_ROOM;
	union {
		
		bool game_ready;
		
		Pos char_pos;
		int resource_type;
		u_short id;
		
		bool game_start;
	}S_wr;

};
#pragma pack()

//ĳ���� ���� ���� ����ü
#pragma pack(1)
struct Character_Select
{
	// PacketInfo�� packetType = 7
	PACK_TYPE packType = PACK_TYPE::SELECT_ROOM;
	int character_type;
	bool go_to_wr;
	int character_left;
	u_short id;
};
#pragma pack()


//���� ���� �Ǵ� ����ü
#pragma pack(1)
struct Game_Info
{
	PACK_TYPE packType = PACK_TYPE::GAME_OVER;
	int score;
	u_short id;
	bool will_replay;
};
#pragma pack()

class PacketClass {
public:
	CharacterInfo packet_Chr[2];
	CarObjectInfo packet_Car;
	ItemObjectInfo packet_Item;
	ObstacleObjectInfo packet_Obs;
	TimeInfo packet_Time;
	Wait_Room packet_Wr[2];
	Character_Select packet_Cs[2];
	Game_Info packet_GI;

	void InitializePacket() {
		packet_Chr[0].packType = PACK_TYPE::CHARACTER_INFO;
		packet_Chr[1].packType = PACK_TYPE::CHARACTER_INFO;
		packet_Chr[0].S_un.char_pos.x = 60;
		packet_Chr[1].S_un.char_pos.x = 640;
		packet_Chr[0].S_un.char_pos.y = 400;
		packet_Chr[1].S_un.char_pos.y = 400;
		packet_Chr[0].S_un.score = 0;
		packet_Chr[1].S_un.score = 0;
		packet_Chr[0].S_un.id = 0;
		packet_Chr[1].S_un.id = 0;
		packet_Chr[0].S_un.life = 10;
		packet_Chr[1].S_un.life = 10;
		packet_Car.packType = PACK_TYPE::OBSTACLE_CAR;
		for (int i = 0; i < 8; ++i)
			packet_Car.posY[i] = 100;
		packet_Item.packType = PACK_TYPE::ITEM_CLICK;
		packet_Item.C_un.item_pos.x = 0;
		packet_Item.C_un.item_pos.y = 0;
		packet_Item.C_un.is_alive = false;
		packet_Item.C_un.id = 0;

		for (int i = 0; i<2; ++i) {
			packet_Wr[i].packType = PACK_TYPE::WAIT_ROOM;
			packet_Wr[i].S_wr.game_ready = false;
			packet_Wr[i].S_wr.game_start = false;
			packet_Wr[i].S_wr.char_pos.x = 0;
			packet_Wr[i].S_wr.char_pos.y = 0;
			packet_Wr[i].S_wr.id = 0;
			packet_Wr[i].S_wr.resource_type = 0;
			packet_Cs[i].packType = PACK_TYPE::SELECT_ROOM;
			packet_Cs[i].character_type = 0;
			packet_Cs[i].go_to_wr = false;
			packet_Cs[i].character_left = 0;
			packet_Cs[i].id = 0;
		}


		packet_GI.packType = PACK_TYPE::GAME_OVER;
		packet_GI.score = 0;
		packet_GI.id = 0;
		packet_GI.will_replay = false;

	}
	void SetCharcterInfo(int num, int x, int y, int tempid, u_short i, int d) {
		if (num < 2) {


		}
	}
	void SetC_SInfo(int c, u_short ids) {
		if (ids-1 < 2) {
			packet_Cs[ids-1].character_type = c;
			if (c == 1)
				packet_Cs[ids-1].character_left = 2;
			else if(c==2)
				packet_Cs[ids-1].character_left = 1;

		}
	}
	

};
